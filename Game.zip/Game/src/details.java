
public class details{ 
	
	
	
	public void Mood(int recalled) {
		
		if (recalled == 1){             
			System.out.print("Today is very good weather and you are enjoyin your day as usual");
		} else if (recalled == 2) {
			System.out.print("Today is weather is poor and you want to watch");
			System.out.print("Gozilla vs Kong but ticket are sold and you had");
			System.out.print("to go outside and happy meal. ");
		} else if (recalled == 3) {
			System.out.print("Today renovation is happening in the house.");
			System.out.print("You don't like renovation but you find out that");
			System.out.print("you really like the design and its good to be open minded");
			System.out.print("and accep change.");
		} else if (recalled == 4) {
			System.out.print("You have find out someone bring cat home and");
			System.out.print("You were excited to see pet but you are find out");
			System.out.print("cats can also be lactose intolerant.");
		} else {
			System.out.println("Unidentified");
		}
	
}
		
}
	
	


