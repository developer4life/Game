import java.util.Scanner; // Calling Scanner method

public class Game{ // Parent class
	
	public static void MessageName(String name){ // Method is declared in parent class
		System.out.println("Hi " + name);        // Message to the user.
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub          
		Scanner input = new Scanner(System.in); 
		String name; int recalled;           
		
		Game objOne = new Game();        
		details objTwo = new details();  
		
		System.out.println("Your name"); 
		name = input.nextLine();
		
		System.out.println("Number for feeling happy(1), sad(2), amusing(3) or shocked(4)?");
		recalled = input.nextInt();    
		
		objOne.MessageName(name);        
		objTwo.Mood(recalled);            
		
		
	}

}
