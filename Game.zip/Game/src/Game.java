import java.util.Scanner; // Calling Scanner method

public class Game{ // Parent class
	
	public static void MessageName(String name){ // Method is declared in parent class
		System.out.println("Hi " + name);        // Message to the user.
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub          
		Scanner input = new Scanner(System.in); 
		String name, recalled;           // Declaring variables
		
		Game objOne = new Game();        // Creating parent class as object.
		details objTwo = new details();  // Creating child class as object.
		
		System.out.println("Your name"); // Message to ask user and input values.
		name = input.nextLine();
		
		System.out.println("Describe your situation happy, sad, amusing or shocked?");
		recalled = input.nextLine();     // User will describe it's mood.   
		
		objOne.MessageName(name);        // First variable will pass value to parent class method. 
		objTwo.Mood(recalled);           // Second variable will pass value to child class method. 
		
		
	}

}
